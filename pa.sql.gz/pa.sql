-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `iklan`;
CREATE TABLE `iklan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(70) NOT NULL,
  `harga` varchar(70) NOT NULL,
  `kategori` varchar(70) NOT NULL,
  `deskripsi` text NOT NULL,
  `foto` text NOT NULL,
  `owner_id` int(255) NOT NULL,
  `verified` bit(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `owner_id` (`owner_id`),
  CONSTRAINT `iklan_ibfk_1` FOREIGN KEY (`owner_id`) REFERENCES `member` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `tgllahir` date NOT NULL,
  `nohp` int(50) NOT NULL,
  `foto` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `member` (`id`, `nama`, `password`, `email`, `tgllahir`, `nohp`, `foto`) VALUES
(2,	'hamzah',	'827ccb0eea8a706c4c34a16891f84e7b',	'asdf@gmail.com',	'1999-02-01',	12345678,	''),
(3,	'hanip',	'd7fa34a9a47ee0f5fd620de7a326ef4a',	'hanip@gmail.com',	'1111-11-11',	12345678,	''),
(4,	'coba1',	'827ccb0eea8a706c4c34a16891f84e7b',	'asdf@gmail.com',	'1999-02-11',	12345678,	''),
(5,	'username',	'827ccb0eea8a706c4c34a16891f84e7b',	'test@email.com',	'3333-02-12',	12345678,	'');

-- 2017-05-29 04:58:56
